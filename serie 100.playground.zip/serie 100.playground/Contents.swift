//: Playground - noun: a place where people can play
// hola
import Cocoa

var str = "Hello, playground"

var numero = 1...100
var numeroes = ""
for num in numero {
   
    if num % 2 == 0 {numeroes = numeroes + "Par\t"}
    if num % 2 != 0 {numeroes = numeroes + "Impar"}
    if num % 5 == 0  {numeroes = numeroes + "\tBINGO"}
    if (num > 29 && num < 41){numeroes = numeroes +  "\t\t\tVIVA SWIFT"}
    print ((num), (numeroes))
    numeroes = ""
    
}


